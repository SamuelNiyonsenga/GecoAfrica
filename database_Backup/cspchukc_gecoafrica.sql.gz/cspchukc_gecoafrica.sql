/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.19-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: cspchukc_gecoafrica
-- ------------------------------------------------------
-- Server version	10.11.19-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `event_img`
--

DROP TABLE IF EXISTS `event_img`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_img` (
  `event_imgID` int(11) NOT NULL AUTO_INCREMENT,
  `event_Mid` int(11) NOT NULL,
  `img_name` varchar(400) NOT NULL,
  `img_order` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` int(11) NOT NULL,
  PRIMARY KEY (`event_imgID`)
) ENGINE=InnoDB AUTO_INCREMENT=144 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_img`
--

LOCK TABLES `event_img` WRITE;
/*!40000 ALTER TABLE `event_img` DISABLE KEYS */;
INSERT INTO `event_img` (`event_imgID`, `event_Mid`, `img_name`, `img_order`, `created_date`, `status`) VALUES (31,1,'1931625510205.jpeg',1,'2021-07-05 18:36:45',0),
(32,1,'24251625510205.jpeg',2,'2021-07-05 18:36:45',0),
(33,11,'13241625515712.jpeg',1,'2021-07-05 20:08:32',0),
(34,11,'1731625515821.jpeg',1,'2021-07-05 20:10:21',0),
(35,11,'29971625515821.jpeg',2,'2021-07-05 20:10:21',0),
(36,11,'3281625515821.jpeg',3,'2021-07-05 20:10:21',0),
(37,11,'48251625515821.jpeg',4,'2021-07-05 20:10:21',0),
(38,11,'55001625515821.jpeg',5,'2021-07-05 20:10:21',0),
(39,11,'19341625515870.jpeg',1,'2021-07-05 20:11:10',0),
(40,11,'29341625515870.jpeg',2,'2021-07-05 20:11:10',0),
(41,11,'38311625515870.jpeg',3,'2021-07-05 20:11:11',0),
(42,1,'18501626196193.jpeg',1,'2021-07-13 17:09:54',0),
(43,1,'21601626196193.jpeg',2,'2021-07-13 17:09:54',0),
(44,1,'37381626196194.jpeg',3,'2021-07-13 17:09:54',0),
(45,1,'44431626196194.jpeg',4,'2021-07-13 17:09:54',0),
(46,1,'59081626196194.jpeg',5,'2021-07-13 17:09:54',0),
(47,1,'16821626196317.jpeg',1,'2021-07-13 17:11:57',0),
(48,1,'21661626196317.jpeg',2,'2021-07-13 17:11:57',0),
(49,12,'19121626962895.jpeg',1,'2021-07-22 14:08:15',0),
(50,12,'26221626962895.jpeg',2,'2021-07-22 14:08:15',0),
(51,12,'3261626962895.jpeg',3,'2021-07-22 14:08:15',0),
(52,12,'44701626962895.jpeg',4,'2021-07-22 14:08:15',0),
(53,13,'17481628754909.jpeg',1,'2021-08-12 07:55:09',0),
(54,13,'21491628754909.jpeg',2,'2021-08-12 07:55:09',0),
(55,13,'34601628754909.jpeg',3,'2021-08-12 07:55:09',0),
(56,13,'46321628754909.jpeg',4,'2021-08-12 07:55:09',0),
(57,14,'14601628755088.jpeg',1,'2021-08-12 07:58:08',0),
(58,14,'21831628755088.jpeg',2,'2021-08-12 07:58:08',0),
(59,14,'36741628755088.jpeg',3,'2021-08-12 07:58:08',0),
(60,14,'43811628755088.jpeg',4,'2021-08-12 07:58:08',0),
(61,14,'59681628755088.jpeg',5,'2021-08-12 07:58:08',0),
(62,14,'13741628755126.jpeg',1,'2021-08-12 07:58:46',0),
(63,15,'14641628755369.jpeg',1,'2021-08-12 08:02:49',0),
(64,15,'2101628755369.jpeg',2,'2021-08-12 08:02:49',0),
(65,15,'39031628755369.jpeg',3,'2021-08-12 08:02:49',0),
(66,15,'42211628755369.jpeg',4,'2021-08-12 08:02:49',0),
(67,15,'59851628755369.jpeg',5,'2021-08-12 08:02:49',0),
(68,15,'17811628755419.jpeg',1,'2021-08-12 08:03:39',0),
(69,15,'26251628755419.jpeg',2,'2021-08-12 08:03:39',0),
(70,16,'15071628755590.jpeg',1,'2021-08-12 08:06:30',0),
(71,16,'2641628755590.jpeg',2,'2021-08-12 08:06:30',0),
(72,16,'35581628755590.jpeg',3,'2021-08-12 08:06:30',0),
(73,16,'43831628755590.jpeg',4,'2021-08-12 08:06:30',0),
(74,16,'55671628755590.jpeg',5,'2021-08-12 08:06:30',0),
(75,16,'13691628755628.jpeg',1,'2021-08-12 08:07:08',0),
(76,17,'1971632328287.jpeg',1,'2021-09-22 16:31:27',0),
(77,17,'26501632328287.jpeg',2,'2021-09-22 16:31:27',0),
(78,17,'33151632328287.jpeg',3,'2021-09-22 16:31:27',0),
(79,17,'41401632328287.jpeg',4,'2021-09-22 16:31:27',0),
(80,17,'53101632328287.jpeg',5,'2021-09-22 16:31:27',0),
(81,18,'15781632328377.jpeg',1,'2021-09-22 16:32:57',0),
(82,18,'27271632328377.jpeg',2,'2021-09-22 16:32:57',0),
(83,19,'11501634219872.jpeg',1,'2021-10-14 13:57:52',0),
(84,19,'24251634219872.jpeg',2,'2021-10-14 13:57:52',0),
(85,19,'37001634219872.jpeg',3,'2021-10-14 13:57:52',0),
(86,19,'16541634219917.jpeg',1,'2021-10-14 13:58:37',0),
(87,19,'21101634219917.jpeg',2,'2021-10-14 13:58:37',0),
(88,19,'38901634219917.jpeg',3,'2021-10-14 13:58:37',0),
(89,19,'41231634219917.jpeg',4,'2021-10-14 13:58:37',0),
(90,20,'14861645473581.jpeg',1,'2022-02-21 19:59:41',0),
(91,20,'27021645473581.jpeg',2,'2022-02-21 19:59:41',0),
(92,20,'38021645473581.jpeg',3,'2022-02-21 19:59:41',0),
(93,20,'47411645473581.jpeg',4,'2022-02-21 19:59:41',0),
(94,20,'57771645473581.jpeg',5,'2022-02-21 19:59:41',0),
(95,21,'11461645473998.jpeg',1,'2022-02-21 20:06:38',0),
(96,21,'24711645473998.jpeg',2,'2022-02-21 20:06:38',0),
(97,21,'38561645473998.jpeg',3,'2022-02-21 20:06:38',0),
(98,21,'48131645473998.jpeg',4,'2022-02-21 20:06:38',0),
(99,22,'13331645474463.jpeg',1,'2022-02-21 20:14:23',0),
(100,22,'27291645474463.jpeg',2,'2022-02-21 20:14:23',0),
(101,22,'31701645474463.jpeg',3,'2022-02-21 20:14:23',0),
(102,22,'45981645474463.jpeg',4,'2022-02-21 20:14:23',0),
(103,22,'5901645474463.jpeg',5,'2022-02-21 20:14:23',0),
(104,22,'11511645474636.jpeg',1,'2022-02-21 20:17:16',0),
(105,22,'27831645474636.jpeg',2,'2022-02-21 20:17:16',0),
(106,22,'39311645474636.jpeg',3,'2022-02-21 20:17:16',0),
(107,23,'13141645474861.jpeg',1,'2022-02-21 20:21:01',0),
(108,23,'28251645474861.jpeg',2,'2022-02-21 20:21:01',0),
(109,23,'31651645474861.jpeg',3,'2022-02-21 20:21:01',0),
(110,24,'14821645475201.jpeg',1,'2022-02-21 20:26:41',0),
(111,24,'25811645475201.jpeg',2,'2022-02-21 20:26:41',0),
(112,24,'3661645475201.jpeg',3,'2022-02-21 20:26:41',0),
(113,24,'42041645475201.jpeg',4,'2022-02-21 20:26:41',0),
(114,24,'59121645475201.jpeg',5,'2022-02-21 20:26:41',0),
(115,25,'13681645475401.jpeg',1,'2022-02-21 20:30:01',0),
(116,25,'2851645475401.jpeg',2,'2022-02-21 20:30:01',0),
(117,25,'35411645475401.jpeg',3,'2022-02-21 20:30:01',0),
(118,25,'41101645475401.jpeg',4,'2022-02-21 20:30:01',0),
(119,26,'17591645475606.jpeg',1,'2022-02-21 20:33:26',0),
(120,26,'23391645475606.jpeg',2,'2022-02-21 20:33:26',0),
(121,26,'33051645475606.jpeg',3,'2022-02-21 20:33:26',0),
(122,26,'44981645475606.jpeg',4,'2022-02-21 20:33:26',0),
(123,27,'1621645475969.jpeg',1,'2022-02-21 20:39:29',0),
(124,27,'22091645475969.jpeg',2,'2022-02-21 20:39:29',0),
(125,27,'36041645475969.jpeg',3,'2022-02-21 20:39:29',0),
(126,27,'43471645475969.jpeg',4,'2022-02-21 20:39:29',0),
(127,27,'51861645475969.jpeg',5,'2022-02-21 20:39:29',0),
(128,27,'12491645476001.jpeg',1,'2022-02-21 20:40:01',0),
(129,28,'19681645476242.jpeg',1,'2022-02-21 20:44:02',0),
(130,28,'21921645476242.jpeg',2,'2022-02-21 20:44:02',0),
(131,28,'38041645476242.jpeg',3,'2022-02-21 20:44:02',0),
(132,28,'47281645476242.jpeg',4,'2022-02-21 20:44:02',0),
(133,28,'51271645476242.jpeg',5,'2022-02-21 20:44:02',0),
(134,28,'13931645476275.jpeg',1,'2022-02-21 20:44:35',0),
(135,29,'13321645476453.jpeg',1,'2022-02-21 20:47:33',0),
(136,29,'2581645476453.jpeg',2,'2022-02-21 20:47:33',0),
(137,29,'36731645476453.jpeg',3,'2022-02-21 20:47:33',0),
(138,30,'14731645517762.jpeg',1,'2022-02-22 08:16:02',0),
(139,30,'28181645517762.jpeg',2,'2022-02-22 08:16:02',0),
(140,30,'39441645517762.jpeg',3,'2022-02-22 08:16:02',0),
(141,31,'1911650357461.jpeg',1,'2022-04-19 08:37:41',0),
(142,31,'29191650357461.jpeg',2,'2022-04-19 08:37:41',0),
(143,31,'33951650357461.jpeg',3,'2022-04-19 08:37:41',0);
/*!40000 ALTER TABLE `event_img` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_events`
--

DROP TABLE IF EXISTS `tb_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_events` (
  `event_id` int(11) NOT NULL AUTO_INCREMENT,
  `event_duration` varchar(200) NOT NULL,
  `event_title` varchar(400) NOT NULL,
  `event_client` varchar(400) NOT NULL,
  `event_date` varchar(200) NOT NULL,
  `event_contents` text NOT NULL,
  `event_postedby` int(11) NOT NULL,
  `event_postedtime` varchar(200) NOT NULL,
  `event_publishedtime` varchar(200) NOT NULL,
  `event_status` varchar(200) NOT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_events`
--

LOCK TABLES `tb_events` WRITE;
/*!40000 ALTER TABLE `tb_events` DISABLE KEYS */;
INSERT INTO `tb_events` (`event_id`, `event_duration`, `event_title`, `event_client`, `event_date`, `event_contents`, `event_postedby`, `event_postedtime`, `event_publishedtime`, `event_status`) VALUES (1,'2021-06','Core drilling at reservoir sites in Ngororero District','WASAC Ltd','June to July 2021','<p>Project: Design review of works for construction of Ngororero water supply system \r\n                            (Muhembe,Nyamyotsi-Kabaya and Nyirarongero water supply systems)in Ngororero District</p>',1,'2021-07-05 17:33:03','','published'),
(11,'2021-06','Detailed topographic survey for the Proposed construction of abattoir,feed mill,feed lot and amenities ','GAKO MEAT COMPANY Ltd','May to June 2021','<p>Detailed topographic survey for the Proposed construction of abattoir,feed mill,feed lot and amenities.<br></p>',1,'2021-07-05 22:07:54','','published'),
(12,'2021-07','Geotechnical investigations for the proposed construction of Center of Excellence in Neurology at CARAES Ndera Hospital','Rwanda Housing Authority ','July 2021','<p>Project: Geotechnical investigations for the proposed construction of Center of Excellence in Neurology at CARAES Ndera Hospital.<br></p>',1,'2021-07-22 16:07:10','','published'),
(13,'2021-08','Geotechnical investigations for the feasibility study,detailed design and preparation of ESIA for upgrading disability playground Project in Gicumbi District','Gicumbi District','August 2021','<p>Geotechnical investigations for the feasibility study,detailed design and preparation of ESIA for upgrading disability playground Project in Gicumbi District.<br></p>',1,'2021-08-12 09:54:05','','published'),
(14,'2021-08','Geotechnical investigations for the Proposed construction of Meeting Hall at Kayenzi,Rwamagana District','CHANOINESSES St AUGUSTIN','August 2021','<p>Geotechnical investigations for the Proposed construction of Meeting Hall at Kayenzi,Rwamagana District.<br></p>',1,'2021-08-12 09:57:25','','published'),
(15,'2021-08','Geotechnical investigations for the project of  construction of Minago drinking water supply system(120.8Km)in Gatsibo District','Gatsibo District',' August 2021','<p><b>Contractor:</b> <u>ECOHYBA Ltd.</u><br></p><p>Geotechnical investigations for the project of&nbsp; construction of Minago drinking water supply system(120.8Km)in Gatsibo District.<br></p>',1,'2021-08-12 10:02:04','','published'),
(16,'2021-08','Geotechnical investigations for the Feasibility and technical studies of Mukarange Sector administrative Office building construction Project','Kayonza District','August 2021','<p><b>Consultant:</b> <u>Nocta Engineering Ltd.</u></p><p>Geotechnical investigations for the Feasibility and technical studies of Mukarange Sector administrative Office building construction Project.<br></p>',1,'2021-08-12 10:06:01','','published'),
(17,'2021-09','Geotechnical investigations for the proposed construction of apartment building ','MWEZE TCHIZA Claude','September 2021','<p><span style=\"font-family: inherit; font-size: inherit; font-style: inherit; font-variant-ligatures: inherit; font-variant-caps: inherit; font-weight: inherit;\">Geotechnical investigations for the proposed construction of apartment building.</span><br></p><p><b>Location:</b>&nbsp;Gisenyi Sector,Rubavu District.<br></p>',1,'2021-09-22 18:30:50','','published'),
(18,'2021-08',' Valuation of executed works for the project of construction of Don Bosco Complex in Nyarutarama,Gasabo District,City of Kigali','Association des Anciens de Don Bosco',' August 2021','<p>&nbsp;Valuation of executed works for the project of construction of Don Bosco Complex in Nyarutarama,Gasabo District,City of Kigali</p><div><br></div>',1,'2021-09-22 18:32:26','','published'),
(19,'2021-10','Geotechnical investigations for the project of Feasibility Study,detailed design and Supervision of Construction Works of Sake Water Supply System(Phase I).','WASAC Ltd','October 2021','<p>Geotechnical investigations for the project of Feasibility Study,detailed design and Supervision of Construction Works of Sake Water Supply System(Phase I).<br></p>',1,'2021-10-14 15:57:04','','published'),
(20,'2021-11','Geotechnical investigations for housing upgrading in Mpazi unplanned settlement ','Skat Consulting Rwanda Ltd','November 2021','<p><b>Location: </b>Akabahizi Cell,Gitega Sector,Nyarugenge District,City of Kigali</p>',1,'2022-02-21 21:58:36','','published'),
(21,'2021-12','Geotechnical investigations for the project of construction of residential buildings ','Nyandwi Jean Claude','December 2021','<p><span style=\"font-family: inherit; font-size: inherit; font-style: inherit; font-variant-ligatures: inherit; font-variant-caps: inherit; font-weight: inherit;\">Location:&nbsp;</span><span style=\"font-family: inherit; font-size: inherit; font-style: inherit; font-variant-ligatures: inherit; font-variant-caps: inherit; font-weight: inherit;\">Nyamata Cell,Nyamata Sector,Nyamata District</span></p>',1,'2022-02-21 22:03:11','','published'),
(22,'2022-01','Topographic Survey of abattoir,feed mill,feed lot and amenities (Phase II:200 Hectares)','GAKO MEAT COMPANY Ltd','January 2022','<p><span style=\"font-family: inherit; font-size: inherit; font-style: inherit; font-variant-ligatures: inherit; font-variant-caps: inherit; font-weight: inherit;\">Location: Bugesera District</span><br></p>',1,'2022-02-21 22:09:28','','published'),
(23,'2022-01','Structural audit of a mixed use building ','WITE FORT PLAZA Ltd','January 2022','<p><span style=\"font-family: inherit; font-size: inherit; font-style: inherit; font-variant-ligatures: inherit; font-variant-caps: inherit; font-weight: inherit;\">Location: Kagera Village,Musezero Cell,Gisozi Sector,Gasabo District</span><br></p>',1,'2022-02-21 22:18:37','','published'),
(24,'2022-02','Geotechnical investigations for the proposed construction of a residential complex(4 Apartments)','Harerimana Jean Bosco','February 2022','<p><span style=\"font-family: inherit; font-size: inherit; font-style: inherit; font-variant-ligatures: inherit; font-variant-caps: inherit; font-weight: inherit;\">Location: Murambi Village,Ruhango Cell,Gisozi Sector,Gasabo District</span><br></p>',1,'2022-02-21 22:23:12','','published'),
(25,'2022-02','Geotechnical investigations for the construction project of a warehouse ','YDH AGRO Ltd','February 2022','<p><span style=\"font-family: inherit; font-size: inherit; font-style: inherit; font-variant-ligatures: inherit; font-variant-caps: inherit; font-weight: inherit;\">Location: Ruhanga Village,Ruhanga Cell,Rusororo Sector,Gasabo District.</span></p>',1,'2022-02-21 22:28:24','','published'),
(26,'2022-02','Geotechnical investigations for the Proposed construction of a warehouse and G+2 Showroom building','JMG Construction and General Traiding Co Ltd','February 2022','<p><span style=\"font-family: inherit; font-size: inherit; font-style: inherit; font-variant-ligatures: inherit; font-variant-caps: inherit; font-weight: inherit;\">Location: Ndera Sector,Gasabo District&nbsp;</span><br></p>',1,'2022-02-21 22:31:43','','published'),
(27,'2022-02','Geotechnical investigations for the Proposed construction of a Petrol Station at Gisozi','COOPERATIVE ADARWA','February 2022','<p><span style=\"font-family: inherit; font-size: inherit; font-style: inherit; font-variant-ligatures: inherit; font-variant-caps: inherit; font-weight: inherit;\">Location: Gasave Village,Musezero Cell,Gisozi Sector,Gasabo District&nbsp;</span><br></p>',1,'2022-02-21 22:35:09','','published'),
(28,'2021-12','Geotechnical investigations for the construction of Rukopfo-Cyarubariro-Rwisi-Simbi-Karambo road in Karongi District','DEC Company Ltd','December 2021','<p>Location:&nbsp;Karongi District</p>',1,'2022-02-21 22:42:27','','published'),
(29,'2021-12','Geotechnical investigations for the proposed construction of Africa New Life Bible Church ','ANLM','December 2021','<p><span style=\"font-family: inherit; font-size: inherit; font-style: inherit; font-variant-ligatures: inherit; font-variant-caps: inherit; font-weight: inherit;\">Location:&nbsp;</span><span style=\"font-family: inherit; font-size: inherit; font-style: inherit; font-variant-ligatures: inherit; font-variant-caps: inherit; font-weight: inherit;\">Kayonza District&nbsp;</span></p>',1,'2022-02-21 22:46:24','','published'),
(30,'2021-11','Construction and extension of Kansi Drinking Water Supply System','World Vision Rwanda/Gisagara District','November 2021','<p><b>Location: </b>Gisagara District,<span style=\"font-family: inherit; font-size: inherit; font-style: inherit; font-variant-ligatures: inherit; font-variant-caps: inherit; font-weight: inherit;\">Kigembe Sector,</span><span style=\"font-family: inherit; font-size: inherit; font-style: inherit; font-variant-ligatures: inherit; font-variant-caps: inherit; font-weight: inherit;\">Impinga Cell</span></p><p><span style=\"font-family: inherit; font-size: inherit; font-style: inherit; font-variant-ligatures: inherit; font-variant-caps: inherit; font-weight: inherit;\"><br></span><span style=\"font-family: inherit; font-size: inherit; font-style: inherit; font-variant-ligatures: inherit; font-variant-caps: inherit;\"><b>Contractor: </b></span><span style=\"font-family: inherit; font-size: inherit; font-style: inherit; font-variant-ligatures: inherit; font-variant-caps: inherit; font-weight: inherit;\">SRDD Ltd</span></p>',1,'2022-02-22 10:14:32','','published');
/*!40000 ALTER TABLE `tb_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_notification`
--

DROP TABLE IF EXISTS `tb_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_notification` (
  `not_id` int(11) NOT NULL AUTO_INCREMENT,
  `notificationn` varchar(4000) NOT NULL,
  `fullnames` varchar(400) NOT NULL,
  `email` varchar(400) NOT NULL,
  `phone` varchar(400) NOT NULL,
  `sent_date` varchar(400) NOT NULL,
  PRIMARY KEY (`not_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_notification`
--

LOCK TABLES `tb_notification` WRITE;
/*!40000 ALTER TABLE `tb_notification` DISABLE KEYS */;
INSERT INTO `tb_notification` (`not_id`, `notificationn`, `fullnames`, `email`, `phone`, `sent_date`) VALUES (12,'hello, i m testing the email form website','JEAN PAUL NSHIMIYIMANA','nshjpaul@gmail.com','250784439238','2019-10-08  21:01:50'),
(13,'Last testing','JEAN PAUL NSHIMIYIMANA','nshjpaul@gmail.com','250784439238','2019-10-08  21:04:37'),
(14,'Hey i m still  testing','Jean paul','nshjpaul@gmail.com','0784439238','2019-10-13  04:28:04'),
(15,'Hello sir,  i have made change so that the client can request services and you receive sms and email. i m waiting for your comment','JEAN PAUL NSHIMIYIMANA','nshjpaul@gmail.com','250784439238','2019-10-14  09:15:38'),
(16,'I am highly appreciated to apply for a professional internship in your company.\r\nI have completed civil engineering bachelor degree studies from the University of Rwanda at College of Science and Technology. I want to keep boosting my engineering skills and knowledge as high as possible so that I can be a fully qualified engineer in my career. \r\nDue to this, I searched for the qualified engineering companies and finally I found that your company is the best company everyone would love to work with. As the one who is willing to give my best as high as possible, I am requesting for a professional internship in your company.\r\n\r\nI wish I should be favored with your reply\r\nYours faithfully, \r\nRobert SENGA','SENGA Robert','sengarobert2020@gmail.com','0781864038','2021-03-12  15:45:31');
/*!40000 ALTER TABLE `tb_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_user_login`
--

DROP TABLE IF EXISTS `tb_user_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_user_login` (
  `login_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_logid` int(11) NOT NULL,
  `log_date` varchar(200) NOT NULL,
  `user_log` varchar(400) NOT NULL,
  `log_time` varchar(400) NOT NULL,
  `log_usertype` varchar(200) NOT NULL,
  PRIMARY KEY (`login_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_user_login`
--

LOCK TABLES `tb_user_login` WRITE;
/*!40000 ALTER TABLE `tb_user_login` DISABLE KEYS */;
INSERT INTO `tb_user_login` (`login_id`, `user_logid`, `log_date`, `user_log`, `log_time`, `log_usertype`) VALUES (1,1,'2021-07-05','on','2021-07-05  15:29:36','ADMIN'),
(2,1,'2021-07-05','on','2021-07-05  15:29:52','ADMIN'),
(3,1,'2021-07-05','on','2021-07-05  17:29:53','ADMIN'),
(4,1,'2021-07-05','on','2021-07-05  19:43:29','ADMIN'),
(5,1,'2021-07-05','on','2021-07-05  19:51:44','ADMIN'),
(6,1,'2021-07-05','on','2021-07-05  21:14:28','ADMIN'),
(7,1,'2021-07-05','on','2021-07-05  21:18:29','ADMIN'),
(8,1,'2021-07-05','on','2021-07-05  21:51:47','ADMIN'),
(9,1,'2021-07-13','on','2021-07-13  19:07:37','ADMIN'),
(10,1,'2021-07-22','on','2021-07-22  16:05:14','ADMIN'),
(11,1,'2021-08-12','on','2021-08-12  09:52:47','ADMIN'),
(12,1,'2021-09-22','on','2021-09-22  18:28:30','ADMIN'),
(13,1,'2021-10-14','on','2021-10-14  15:55:27','ADMIN'),
(14,1,'2022-02-21','on','2022-02-21  21:55:07','ADMIN'),
(15,1,'2022-02-22','on','2022-02-22  10:00:07','ADMIN'),
(16,1,'2022-04-19','on','2022-04-19  09:37:30','ADMIN'),
(17,1,'2022-04-19','on','2022-04-19  10:24:46','ADMIN'),
(18,1,'2022-04-19','on','2022-04-19  10:26:38','ADMIN'),
(19,1,'2022-04-19','on','2022-04-19  10:35:57','ADMIN');
/*!40000 ALTER TABLE `tb_user_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_users`
--

DROP TABLE IF EXISTS `tb_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_users` (
  `userID` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(200) NOT NULL,
  `lname` varchar(200) NOT NULL,
  `useremail` varchar(200) NOT NULL,
  `passcode` varchar(200) NOT NULL,
  `userphone` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  `regdate` varchar(200) NOT NULL,
  `regby` int(11) NOT NULL,
  PRIMARY KEY (`userID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_users`
--

LOCK TABLES `tb_users` WRITE;
/*!40000 ALTER TABLE `tb_users` DISABLE KEYS */;
INSERT INTO `tb_users` (`userID`, `fname`, `lname`, `useremail`, `passcode`, `userphone`, `status`, `regdate`, `regby`) VALUES (1,'JEAN PAUL','NSHMIYIMANA','info@gecoafrica.com','$2y$10$BWjC.t6xvt5vizvnQKGOWeYisoxLgfzL8R5N4Mv9tGvIxhTRhLYUK','0784439238','OFF','',1);
/*!40000 ALTER TABLE `tb_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'cspchukc_gecoafrica'
--

--
-- Dumping routines for database 'cspchukc_gecoafrica'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-21 15:28:54
